#!/usr/bin/env python
# coding: utf-8

from xbmcswift2 import Plugin
import urlfetch
from BeautifulSoup import BeautifulSoup
import xbmcaddon
import xbmcgui
import xbmc
import json
import re
import urllib
import base64

plugin = Plugin()
crawurl = 'https://fptplay.net/'
__setting= xbmcaddon.Addon(id='plugin.video.fptiptv')
fl=__setting.getSetting('file')	
dophangiai=__setting.getSetting('quality')
'''
result = urlfetch.fetch(
        "https://fptplay.net/livetv/vtv2",
		headers={
            'User-Agent':'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.81 Safari/537.36',
			'Referer':'https://fptplay.net/'
            })
cookie21='laravel_session=' + result.cookies.get('laravel_session') + ";"
cookie2='token=' + result.cookies.get('token') + ";"
'''

def htv(url= None):
	resultvtv = urlfetch.fetch(
        url,
		headers={
            'User-Agent':'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.81 Safari/537.36',
            })

	htv=resultvtv.content
	
	match = re.search(r'Main\.setUpPlayer\(\'(.*?)\'',htv)
	
	
	return match.group(1)
	




xbmc.executebuiltin('StopPVRManager')
xbmc.executebuiltin("ActivateWindow(10000)")
pDialog = xbmcgui.DialogProgress()
pDialog.create('[COLOR yellow]Lấy danh sách tv[/COLOR]','[COLOR red][B] Đang tải...[/B][/COLOR]')


foo =open(fl,'w')
foo.write("#EXTM3U\n")
ten=['Cần thơ','Vĩnh Long 1','Vĩnh Long 2','Đồng Tháp','VTV1','VTV2','VTV3','VTV6','VTC1','VTC3','VTC14-Tin tức','HTV2','HTV3','HTV4','HTV7']
dd=['http://htvonline.com.vn/livetv/can-tho-thtpct-3130336E61.html','http://htvonline.com.vn/livetv/thvl1-vinh-long-36326E61.html','http://htvonline.com.vn/livetv/vinh-long-2-3136366E61.html','http://htvonline.com.vn/livetv/dong-thap-thdt-36306E61.html','http://htvonline.com.vn/livetv/vtv1-32316E61.html','http://htvonline.com.vn/livetv/vtv2-37326E61.html',"http://htvonline.com.vn/livetv/vtv3-32306E61.html","http://htvonline.com.vn/livetv/vtv6-37336E61.html",'http://htvonline.com.vn/livetv/vtc1hd-3137386E61.html','http://htvonline.com.vn/livetv/vtc3-hd-3133376E61.html','http://htvonline.com.vn/livetv/vtc14sd-3137326E61.html','http://htvonline.com.vn/livetv/htv2-3132326E61.html','http://htvonline.com.vn/livetv/htv3-34396E61.html','http://htvonline.com.vn/livetv/htv4-35306E61.html','http://htvonline.com.vn/livetv/htv7-sd-3131336E61.html']


for x in range (0,15):
	
	foo.write("#EXTINF:-1,"+ten[x]+'\n')
	foo.write(htv(dd[x])+'\n')
	pDialog.update(x*4,"[COLOR red][B] Đang thêm [/B][/COLOR]"+ten[x])

foo.close()
pDialog.close()
xbmc.executebuiltin('StartPVRManager')
xbmc.executebuiltin("ActivateWindow(10615)")


 