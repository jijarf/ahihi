#!/usr/bin/env python
# coding: utf-8

from xbmcswift2 import Plugin
import urlfetch

import xbmcaddon
import xbmcgui
import xbmc
import json
import re
import urllib
import base64

plugin = Plugin()
crawurl = 'https://fptplay.net/'
__setting= xbmcaddon.Addon(id='plugin.video.fptiptv')
fl=__setting.getSetting('file')	
dophangiai=__setting.getSetting('quality')
dophangiai2=__setting.getSetting('quality2')
dophangiai2=int(dophangiai2)
'''sctv fake'''
device_model    = 'Samsung+SM-J320H'
fake_device_id  = '852712'
manufacturer_id = '7AA792C7B615128915A7C6C49E6577F1'
tok             = 'VjNqT05kcTVUMDVrUnpWVU1YQnJVbXBXVUZaclNsTlZSbEYzVUZFOVBRPT0='

'''
result = urlfetch.fetch(
        "https://fptplay.net/user/login",
		data={"phone": "",
            "password": "",
            "submit":""
            },
        headers={
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.89 Safari/537.36',
			'Referer':'https://fptplay.net/'
            })
cookie2='laravel_session=' + result.cookies.get('laravel_session') + ";"
'''
cookie2=''
def vtvplay(url=None):
	resultvtv = urlfetch.fetch(
        url,
		headers={
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.89 Safari/537.36'
			
            })

	infovtv=resultvtv.content

	match = re.search(r'.Base64\.decod4e\(\"(.*?)\"',infovtv)

	linkvtv=base64.b64decode(match.group(1))	
	return linkvtv
	
def htv(url=None):
	resultvtv = urlfetch.fetch(
        url,
		headers={
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.89 Safari/537.36',
			'Referer':url
            })

	infovtv=resultvtv.content

	match = re.search(r'Main\.setUpPlayer\(\'(.*?)\'',infovtv)

	linkvtv=match.group(1)	
	return linkvtv
	
def getLinkById(id = None, quality = "2",cookie =None):

    #plugin.log.info(csrf)
    result = urlfetch.post(
        'https://fptplay.net/show/getlinklivetv',
        data={"id": id,
            "quality": 3,
            "mobile": "web",
			"type" : "newchannel"
            },
        headers={'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.89 Safari/537.36',
                'X-Requested-With':'XMLHttpRequest',
                'Referer':'https://fptplay.net/livetv',
				'X-KEY':'123456',
                'cookie':cookie
                }
        )
    
    if result.status_code != 200 :
        return None
	
    info = json.loads(result.content)
    return info['stream']

xbmc.executebuiltin('StopPVRManager')
xbmc.executebuiltin("ActivateWindow(10000)")
pDialog = xbmcgui.DialogProgress()
pDialog.create('[COLOR yellow]Lấy danh sách tv[/COLOR]','[COLOR red][B] Đang tải...[/B][/COLOR]')
dpg=["chunklist_b300000","chunklist_b500000","chunklist_b1200000","chunklist_b2500000","chunklist_b550000","chunklist_b1300000"]
d=int(dophangiai)
foo =open(fl,'w')
foo.write("#EXTM3U\n")
ten=['Cần thơ','Vĩnh Long 1','Vĩnh Long 2','Đồng Tháp','VTV1','VTV2','VTV3','VTV6','VTC1','VTC2','VTC3','VTC4','VTC9 LETS VIET','VTC14-Tin tức','HTV2','HTV3','HTV4','HTV7','Tiền Giang','An giang','Hậu Giang','Phim','[COLOR yellow]Kênh Phim[/COLOR]','[COLOR yellow]Thể thao tv[/COLOR]','[COLOR yellow]Bóng đá tv[/COLOR]']
dd=['can-tho','thvl1','vinh-long-2','dong-thap','vtv1-hd','vtv2',"vtv3-hd","vtv6-hd",'vtc1','vtc2','vtc3-hd','yeah1-family-vtc4','lets-viet','vtc14-hd','htv2','htv3','htv4','htv7-hd','tien-giang','an-giang','hau-giang','imovie-hd','kenh-phim','the-thao-tv','bong-da-tv',]
vip1=['premier-league-bltv','premier-league-bltv2']
vip2=['premier-league-1','premier-league-2','premier-league-3','premier-league-4','premier-league-5']
vip3=['http://vtvplay.vn/kenh-truyen-hinh/vtvcab16-sd-live144','http://vtvplay.vn/kenh-truyen-hinh/vtvcab3-live145']
vip4=['Bóng đá TV','Thể thao TV']

for x in range (0,6):
	temp=getLinkById(dd[x],2,cookie2)
	foo.write("#EXTINF:-1,"+ten[x]+'\n')
	foo.write(temp.replace("playlist",dpg[d],1)+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36&Referer=https://fptplay.net/livek/\n')
	pDialog.update(x*4,"[COLOR red][B] Đang thêm [/B][/COLOR]"+ten[x])

for x in range (6,7):
	temp=getLinkById(dd[x],2,cookie2)
	foo.write("#EXTINF:-1,"+ten[x]+'\n')
	foo.write(temp.replace("playlist",dpg[dophangiai2],1)+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36&Referer=https://fptplay.net/livek/\n')
	pDialog.update(x*4,"[COLOR red][B] Đang thêm [/B][/COLOR]"+ten[x])	

for x in range (7,8):
	temp=getLinkById(dd[x],2,cookie2)
	foo.write("#EXTINF:-1,"+ten[x]+'\n')
	foo.write(temp.replace("playlist", dpg[dophangiai2],1)+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36&Referer=https://fptplay.net/livek/\n')
	pDialog.update(x*4,"[COLOR red][B] Đang thêm [/B][/COLOR]"+ten[x])	
	
for x in range (8,18):
	temp=getLinkById(dd[x],2,cookie2)
	foo.write("#EXTINF:-1,"+ten[x]+'\n')
	foo.write(temp.replace("playlist",dpg[d],1)+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36&Referer=https://fptplay.net/livek/\n')
	pDialog.update(x*4,"[COLOR red][B] Đang thêm [/B][/COLOR]"+ten[x])	

foo.write("#EXTINF:-1,HTV9\n")
foo.write(htv('http://htvonline.com.vn/livetv/htv9-sd-3131346E61.html')+'\n')	
	
	
for x in range (18,22):
	temp=getLinkById(dd[x],2,cookie2)
	foo.write("#EXTINF:-1,"+ten[x]+'\n')
	foo.write(temp.replace("playlist",dpg[d],1)+'|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36&Referer=https://fptplay.net/livek/\n')
	pDialog.update(x*4,"[COLOR red][B] Đang thêm [/B][/COLOR]"+ten[x])	
'''
for x in range (0,2):	
	foo.write("#EXTINF:-1,[COLOR aqua]"+vip4[x]+'[/COLOR]\n')
	foo.write(vtvplay(vip3[x])+'\n')
	
 '''
 
 
 
foo.close()
pDialog.close()
xbmc.executebuiltin('StartPVRManager')
xbmc.executebuiltin("ActivateWindow(10615)")


 